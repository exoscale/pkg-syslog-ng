#ifndef TEST_LOGPROTO_H_INCLUDED
#define TEST_LOGPROTO_H_INCLUDED

void test_log_proto_server_options(void);
void test_log_proto_record_server(void);
void test_log_proto_text_server(void);
void test_log_proto_indented_multiline_server(void);
void test_log_proto_regexp_multiline_server(void);
void test_log_proto_dgram_server(void);
void test_log_proto_framed_server(void);

#endif
