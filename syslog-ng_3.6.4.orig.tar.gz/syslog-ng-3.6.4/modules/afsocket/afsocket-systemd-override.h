#ifndef AFSOCKET_GRAMMAR_EXTRA_H_INCLUDED
#define AFSOCKET_GRAMMAR_EXTRA_H_INCLUDED

void afunix_grammar_set_source_driver(AFUnixSourceDriver *sd);
void systemd_syslog_grammar_set_source_driver(SystemDSyslogSourceDriver *sd);

#endif
